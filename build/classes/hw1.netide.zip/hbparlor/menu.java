/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hbparlor;
import java.util.Scanner;
/**
 *
 * @author Craig
 */
public class menu {
    public String customer;
    public String icecream;
    public int serving;
    public String worker;
    public int orderNo = 1;
    public Order orderObj;
    
    public void menuRun()
    {
        Scanner input = new Scanner(System.in);
        Shop shopObj = new Shop();
        
        boolean run;
        run = true;
        
        while(run == true)
        {
            System.out.print("Ice Cream Main Menu\n\n \t1. Create Menu\n\t2. Update Menu\n\t3. Display\n\t4. Quit\n");
            switch(input.nextInt())
            {
            case 1:
                System.out.print("Create Menu\n\n\t1. Create Ice Cream\n\t2. Create Serving\n\t3. Create Customer\n\t4. Create Worker\n\t5. Create Order\n\t6. Return to Previous Menu\n");
                switch(input.nextInt())
                {
                    case 1:
                        icecream = shopObj.newIcecream();
                        break;
                    case 2:
                        serving = shopObj.newServing();
                        break;
                    case 3:
                        customer = shopObj.newCustomer();
                        break;
                    case 4:
                        worker = shopObj.newWorker();
                        break;
                    case 5:
                        orderObj = shopObj.newOrder(icecream, serving, customer, worker, orderNo);
                        orderNo += 1;
                        break;
                    case 6:
                       break;
                        
                    default:
                        System.out.print("Create Menu\n\n\t1. Create Ice Cream\n\t2. Create Serving\n\t3. Create Customer\n\t4. Create Worker\n\t5. Create Order\n\t6. Return to Previous Menu\n");
                }
                break;
            
            case 2:
                System.out.print("Update Menu\n\n\t1. Update Ice Cream\n\t2. Update Serving\n\t3. Update Customer\n\t4. Update Worker\n\t5. Update Order\n\t6. Return to Previous Menu\n");
                switch(input.nextInt())
                {
                    case 1:
                        icecream = shopObj.newIcecream();
                        break;
                    case 2:
                        serving = shopObj.newServing();
                        break;
                    case 3:
                        customer = shopObj.newCustomer();
                        break;
                    case 4:
                        worker = shopObj.newWorker();
                        break;
                    case 5:
                        orderObj = shopObj.newOrder(icecream, serving, customer, worker, orderNo);
                        orderNo += 1;
                        break;
                    case 6:
                        break;
                    default:
                        System.out.print("Update Menu\n\n\t1. Update Ice Cream\n\t2. Update Serving\n\t3. Update Customer\n\t4. Update Worker\n\t5. Update Order\n\t6. Return to Previous Menu\n");
                }
                break;
                
            case 3:
                System.out.print("STATUS\n\n-----------------\n\n");
                System.out.printf("Order Number: %d\n\n", orderObj.getNum());
                System.out.printf("Customer: %s\n\n", orderObj.getCust());
                System.out.printf("Worker: %s\n\n", orderObj.getWorker());
                System.out.printf("Serving: %s\n\n", orderObj.getServe());
                System.out.printf("Contains: \n%s\n", orderObj.getFlavor());
                break;
                
            case 4:
                System.exit(0);
                
            default:
                System.out.print("Ice Cream Main Menu\n\n \t1. Create Menu\n\t2. Update Menu\n\t3. Display\n\t4. Quit\n");
            }
        }
        
    }
}
