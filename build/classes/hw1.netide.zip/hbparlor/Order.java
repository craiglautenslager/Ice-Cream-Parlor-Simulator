/*Craig Lautenslager
*#100073407
*9/14/15 CSE 1325-003
*/
package hbparlor;


public class Order {
    
    public int orderNum;
    public String customer;
    public String worker;
    public String flavor;
    public int serving;
    
    public Order(int num)
    {
        this.orderNum = num;
    }
    
    public void setNum(int orderNum)
    {
        this.orderNum = orderNum;
    }
    
    public int getNum()
    {
        return orderNum;
    }
    
    public void setCust(String name)
    {
        this.customer = name;
    }
    
    public String getCust()
    {
        return customer;
    }
    
    public void setWorker(String name)
    {
        this.worker = name;
    }
    
    public String getWorker()
    {
        return worker;
    }
    
    public void setFlavor(String flavor)
    {
        this.flavor = flavor;
    }
    
    public String getFlavor()
    {
        return flavor;
    }
    
    public void setServe(int num)
    {
        this.serving = num;
    }
    
    public int getServe()
    {
        return serving;
    }
    
}
