/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hbparlor;
import java.util.Scanner;
/**
 *
 * @author Craig
 */
public class Shop {
    
    public String newCustomer()
    {
        
        System.out.print("Enter Customer Name: ");
        Scanner input = new Scanner(System.in);
        Customer cstmrObj = new Customer(input.nextLine());
        return cstmrObj.getName();
        
    }
    
    public String newIcecream()
    {
        System.out.print("Ice Cream Created\n");
        System.out.print("Flavor: ");
        Scanner input = new Scanner(System.in);
        IceCream icObj = new IceCream();
        icObj.setFlavor(input.nextLine());
        System.out.print("Price: ");
        icObj.setPrice(input.nextDouble());
        System.out.print("Description: ");
        icObj.setDescrip(input.nextLine());
        return icObj.getFlavor();
        
    }
    
    public int newServing()
    {
        System.out.print("Serving Created\n");
        System.out.print("Enter Number of Servings: ");
        Scanner input = new Scanner(System.in);
        Serving serveObj = new Serving();
        serveObj.setNum(input.nextInt());
        System.out.print("Enter Price per Serving: ");
        serveObj.setPrice(input.nextDouble());
        return serveObj.getNum();
    }
    
    public String newWorker()
    {
        
        System.out.print("Worker Created\n");
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Worker Name: ");
        Worker workerObj = new Worker(input.nextLine());
        return workerObj.getName();
    }
    
    public Order newOrder(String icecream, int serving, String customer, String worker, int orderNo)
    {
        Order orderObj = new Order(orderNo);
        
        orderObj.setCust(customer);
        orderObj.setWorker(worker);
        orderObj.setServe(serving);
        orderObj.setFlavor(icecream);
        
        return orderObj;
        
    }
}
