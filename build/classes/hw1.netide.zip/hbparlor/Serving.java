/*Craig Lautenslager
*#100073407
*9/14/15 CSE 1325-003
*/
package hbparlor;

/**
 *
 * @author Craig
 */
public class Serving {
    
    public int flavorNum;
    public double servePrice;
    
    public void setNum(int flavorNum)
    {
        this.flavorNum = flavorNum;
    }
    
    public int getNum()
    {
        return flavorNum;
    }
    
    public void setPrice(double servePrice)
    {
        if(servePrice > 0.0)
            this.servePrice = servePrice * flavorNum;
    }
    
    public double getPrice()
    {
        return servePrice;
    }
    
}
