/*Craig Lautenslager
*#100073407
*9/14/15 CSE 1325-003
*/
package hbparlor;

/**
 *
 * @author Craig
 */
public class IceCream {
    
    public String flavor;
    public Double price;
    public String name;
    public String descrip;
    
    public void setFlavor(String flavor)
    {
        this.flavor = flavor;
    }
    
    public String getFlavor()
    {
        return flavor;
    }
    
    public void setPrice(Double price)
    {
        if(price > 0.0)
            this.price = price;
    }
    
    public Double getPrice()
    {
        return price;
    }
    
    public void setDescrip(String descrip)
    {
        this.descrip = descrip;
    }
    
    public String getDescrip()
    {
        return descrip;
    }
    
}
