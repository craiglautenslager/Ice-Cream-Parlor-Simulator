/*Craig Lautenslager
*#100073407
*9/14/15 CSE 1325-003
*/
package hbparlor;

/**
 *
 * @author Craig
 */
public class Customer {
    
    public String name;
    public int happy;
    public Double moneyBal;
    
    public Customer(String name)
    {
        this.name = name;
        System.out.print("Customer Created");
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setHappy(int happy)
    {
        this.happy = happy;
    }
    
    public int gethappy()
    {
        return happy;
    }
    
    public void setBalance(Double moneyBal)
    {
        if(moneyBal > 0.0)
            this.moneyBal = moneyBal;
    }
    
    public Double getBalance()
    {
        return moneyBal;
    }
}
