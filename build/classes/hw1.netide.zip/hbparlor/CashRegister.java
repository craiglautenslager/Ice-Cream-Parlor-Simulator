/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hbparlor;

/**
 *
 * @author Craig
 */
public class CashRegister {
    
    public Double balance;
    
    public CashRegister(Double balance)
    {
        this.balance = balance;
    }
    
    public void setBalance(Double balance)
    {
        if(balance > 0.0)
            this.balance = this.balance + balance;
    }
    
    public Double getBalance()
    {
        return balance;
    }
}
