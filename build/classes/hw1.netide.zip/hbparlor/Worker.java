/*Craig Lautenslager
*#100073407
*9/14/15 CSE 1325-003
*/
package hbparlor;

/**
 *
 * @author Craig
 */
public class Worker {
    
    public String name;
    
    public Worker(String name)
    {
        this.name = name;
        System.out.print("Worker Created");
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
}
